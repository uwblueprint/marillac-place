/*
  Warnings:

  - The values [ACHIEVEMENT] on the enum `TaskType` will be removed. If these variants are still used in the database, this will fail.
  - The primary key for the `tasks` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `credit_value` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `description` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `end_date` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `id` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `recurrence_frequency` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `repeat_days` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `specific_day` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `title` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the `NotificationGroup` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `_NotificationGroupToResident` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `notifications` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `notifications_received` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `residents` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `staff` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `tasks_assigned` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `users` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `warnings` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `credit` to the `tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `end` to the `tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `is_recurring` to the `tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `name` to the `tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `start` to the `tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `status` to the `tasks` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "StaffType" AS ENUM ('ADMIN', 'RELIEF');

-- CreateEnum
CREATE TYPE "TaskStatus" AS ENUM ('ASSIGNED', 'INCOMPLETE', 'COMPLETE', 'EXCUSED');

-- AlterEnum
BEGIN;
CREATE TYPE "TaskType_new" AS ENUM ('REQUIRED', 'OPTIONAL', 'CHORE');
ALTER TABLE "tasks" ALTER COLUMN "type" TYPE "TaskType_new" USING ("type"::text::"TaskType_new");
ALTER TYPE "TaskType" RENAME TO "TaskType_old";
ALTER TYPE "TaskType_new" RENAME TO "TaskType";
DROP TYPE "TaskType_old";
COMMIT;

-- DropForeignKey
ALTER TABLE "_NotificationGroupToResident" DROP CONSTRAINT "_NotificationGroupToResident_A_fkey";

-- DropForeignKey
ALTER TABLE "_NotificationGroupToResident" DROP CONSTRAINT "_NotificationGroupToResident_B_fkey";

-- DropForeignKey
ALTER TABLE "notifications" DROP CONSTRAINT "notifications_author_id_fkey";

-- DropForeignKey
ALTER TABLE "notifications" DROP CONSTRAINT "notifications_group_id_fkey";

-- DropForeignKey
ALTER TABLE "notifications_received" DROP CONSTRAINT "notifications_received_notification_id_fkey";

-- DropForeignKey
ALTER TABLE "notifications_received" DROP CONSTRAINT "notifications_received_recipient_id_fkey";

-- DropForeignKey
ALTER TABLE "residents" DROP CONSTRAINT "residents_user_id_fkey";

-- DropForeignKey
ALTER TABLE "staff" DROP CONSTRAINT "staff_user_id_fkey";

-- DropForeignKey
ALTER TABLE "tasks_assigned" DROP CONSTRAINT "tasks_assigned_assignee_id_fkey";

-- DropForeignKey
ALTER TABLE "tasks_assigned" DROP CONSTRAINT "tasks_assigned_assigner_id_fkey";

-- DropForeignKey
ALTER TABLE "tasks_assigned" DROP CONSTRAINT "tasks_assigned_task_id_fkey";

-- DropForeignKey
ALTER TABLE "warnings" DROP CONSTRAINT "warnings_assigner_id_fkey";

-- DropForeignKey
ALTER TABLE "warnings" DROP CONSTRAINT "warnings_related_task_id_fkey";

-- DropForeignKey
ALTER TABLE "warnings" DROP CONSTRAINT "warnings_resident_id_fkey";

-- AlterTable
ALTER TABLE "tasks" DROP CONSTRAINT "tasks_pkey",
DROP COLUMN "credit_value",
DROP COLUMN "description",
DROP COLUMN "end_date",
DROP COLUMN "id",
DROP COLUMN "recurrence_frequency",
DROP COLUMN "repeat_days",
DROP COLUMN "specific_day",
DROP COLUMN "title",
ADD COLUMN     "comment" TEXT,
ADD COLUMN     "credit" INTEGER NOT NULL,
ADD COLUMN     "end" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "is_recurring" BOOLEAN NOT NULL,
ADD COLUMN     "name" TEXT NOT NULL,
ADD COLUMN     "room_number" INTEGER,
ADD COLUMN     "start" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "status" "TaskStatus" NOT NULL,
ADD COLUMN     "task_id" SERIAL NOT NULL,
ADD CONSTRAINT "tasks_pkey" PRIMARY KEY ("task_id");

-- DropTable
DROP TABLE "NotificationGroup";

-- DropTable
DROP TABLE "_NotificationGroupToResident";

-- DropTable
DROP TABLE "notifications";

-- DropTable
DROP TABLE "notifications_received";

-- DropTable
DROP TABLE "residents";

-- DropTable
DROP TABLE "staff";

-- DropTable
DROP TABLE "tasks_assigned";

-- DropTable
DROP TABLE "users";

-- DropTable
DROP TABLE "warnings";

-- DropEnum
DROP TYPE "DaysOfWeek";

-- DropEnum
DROP TYPE "RecurrenceFrequency";

-- DropEnum
DROP TYPE "Status";

-- DropEnum
DROP TYPE "UserType";

-- CreateTable
CREATE TABLE "participants" (
    "participant_id" INTEGER NOT NULL,
    "room_number" INTEGER NOT NULL,
    "arrival" TIMESTAMP(3) NOT NULL,
    "departure" TIMESTAMP(3),
    "is_active" BOOLEAN NOT NULL,
    "password" TEXT NOT NULL,
    "credit_earned" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "participants_pkey" PRIMARY KEY ("participant_id")
);

-- CreateTable
CREATE TABLE "announcements" (
    "announcement_id" SERIAL NOT NULL,
    "from" "StaffType" NOT NULL,
    "to" INTEGER[],
    "createdAt" TIMESTAMP(3) NOT NULL,
    "message" TEXT NOT NULL,

    CONSTRAINT "announcements_pkey" PRIMARY KEY ("announcement_id")
);
