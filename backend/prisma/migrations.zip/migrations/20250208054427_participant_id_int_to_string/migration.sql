/*
  Warnings:

  - The primary key for the `participants` table will be changed. If it partially fails, the table could be left without primary key constraint.

*/
-- AlterTable
ALTER TABLE "participants" DROP CONSTRAINT "participants_pkey",
ALTER COLUMN "participantId" SET DATA TYPE TEXT,
ADD CONSTRAINT "participants_pkey" PRIMARY KEY ("participantId");
