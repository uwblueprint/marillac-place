-- AlterTable
ALTER TABLE "participants" ALTER COLUMN "arrival" SET DATA TYPE TEXT,
ALTER COLUMN "departure" SET DATA TYPE TEXT;
