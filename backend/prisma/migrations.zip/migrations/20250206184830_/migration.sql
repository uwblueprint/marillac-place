/*
  Warnings:

  - The values [CHORE] on the enum `TaskType` will be removed. If these variants are still used in the database, this will fail.
  - The primary key for the `announcements` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `announcement_id` on the `announcements` table. All the data in the column will be lost.
  - The primary key for the `participants` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `credit_earned` on the `participants` table. All the data in the column will be lost.
  - You are about to drop the column `is_active` on the `participants` table. All the data in the column will be lost.
  - You are about to drop the column `participant_id` on the `participants` table. All the data in the column will be lost.
  - You are about to drop the column `room_number` on the `participants` table. All the data in the column will be lost.
  - The primary key for the `tasks` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `is_recurring` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `room_number` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the column `task_id` on the `tasks` table. All the data in the column will be lost.
  - Added the required column `participantId` to the `participants` table without a default value. This is not possible if the table is not empty.
  - Added the required column `roomNumber` to the `participants` table without a default value. This is not possible if the table is not empty.
  - Added the required column `isRecurring` to the `tasks` table without a default value. This is not possible if the table is not empty.

*/
-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "TaskStatus" ADD VALUE 'UNASSIGNED';
ALTER TYPE "TaskStatus" ADD VALUE 'PENDING';

-- AlterEnum
BEGIN;
CREATE TYPE "TaskType_new" AS ENUM ('REQUIRED', 'OPTIONAL');
ALTER TABLE "tasks" ALTER COLUMN "type" TYPE "TaskType_new" USING ("type"::text::"TaskType_new");
ALTER TYPE "TaskType" RENAME TO "TaskType_old";
ALTER TYPE "TaskType_new" RENAME TO "TaskType";
DROP TYPE "TaskType_old";
COMMIT;

-- AlterTable
ALTER TABLE "announcements" DROP CONSTRAINT "announcements_pkey",
DROP COLUMN "announcement_id",
ADD COLUMN     "announcementId" SERIAL NOT NULL,
ADD CONSTRAINT "announcements_pkey" PRIMARY KEY ("announcementId");

-- AlterTable
ALTER TABLE "participants" DROP CONSTRAINT "participants_pkey",
DROP COLUMN "credit_earned",
DROP COLUMN "is_active",
DROP COLUMN "participant_id",
DROP COLUMN "room_number",
ADD COLUMN     "credit" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "participantId" INTEGER NOT NULL,
ADD COLUMN     "roomNumber" INTEGER NOT NULL,
ADD CONSTRAINT "participants_pkey" PRIMARY KEY ("participantId");

-- AlterTable
ALTER TABLE "tasks" DROP CONSTRAINT "tasks_pkey",
DROP COLUMN "is_recurring",
DROP COLUMN "room_number",
DROP COLUMN "task_id",
ADD COLUMN     "isRecurring" BOOLEAN NOT NULL,
ADD COLUMN     "roomNumber" INTEGER,
ADD COLUMN     "taskId" SERIAL NOT NULL,
ADD CONSTRAINT "tasks_pkey" PRIMARY KEY ("taskId");
